alter table tblMain
add CustName varchar(50)

alter table tblMain
add CustPhone varchar(50)

alter table tblMain
add driverID int

select * from tblMain