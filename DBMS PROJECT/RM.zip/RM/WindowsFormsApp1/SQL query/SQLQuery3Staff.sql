﻿create table staff
(
staffID int primary key identity,
sName varchar(50),
sPhone varchar(50),
sRole varchar(50)
)