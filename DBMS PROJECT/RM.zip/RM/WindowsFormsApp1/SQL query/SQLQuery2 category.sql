﻿create table tables
(
tid int primary key identity,
tname varchar(15)
)