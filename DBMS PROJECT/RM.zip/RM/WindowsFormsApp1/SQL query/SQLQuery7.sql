﻿select * from tblMain
select * from tblDetails